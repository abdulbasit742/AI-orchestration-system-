import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Brain, Send, Sparkles, TrendingUp, Mail, Share2, FileText, Target, 
  BarChart3, Lightbulb, Code, ShoppingCart, Users, DollarSign, Briefcase,
  Palette, MessageSquare, Settings, Activity, Zap, Network, CheckCircle,
  Clock, AlertCircle, Loader, Database, Globe, Cpu, Key, Eye, EyeOff,
  Save, X, Download, History, Star, TrendingDown, Wifi, WifiOff
} from 'lucide-react';

export default function MasterOrchestratorUltraOptimized() {
  // Core state
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeAgents, setActiveAgents] = useState([]);
  const [systemStatus, setSystemStatus] = useState('operational');
  
  // Advanced state
  const [taskQueue, setTaskQueue] = useState([]);
  const [agentInsights, setAgentInsights] = useState({});
  const [showSettings, setShowSettings] = useState(false);
  const [apiKeys, setApiKeys] = useState({});
  const [selectedModel, setSelectedModel] = useState('claude');
  const [showApiKey, setShowApiKey] = useState({});
  
  // Optimization state
  const [queryCache, setQueryCache] = useState({});
  const [routingHistory, setRoutingHistory] = useState([]);
  const [modelPerformance, setModelPerformance] = useState({});
  const [totalCost, setTotalCost] = useState(0);
  const [isOnline, setIsOnline] = useState(true);
  const [queryHistory, setQueryHistory] = useState([]);
  
  // AI Models with cost tracking
  const aiModels = {
    claude: {
      id: 'claude',
      name: 'Claude',
      icon: '🤖',
      models: ['claude-sonnet-4-20250514'],
      defaultModel: 'claude-sonnet-4-20250514',
      endpoint: 'https://api.anthropic.com/v1/messages',
      needsKey: false,
      description: 'FREE - Best for reasoning',
      color: 'from-purple-600 to-pink-600',
      category: 'Free',
      cost: 0, // FREE!
      speed: 'medium',
      reliability: 0.98
    },
    ollama: {
      id: 'ollama',
      name: 'Ollama',
      icon: '🦙',
      models: ['llama2', 'mistral', 'codellama', 'phi', 'neural-chat'],
      defaultModel: 'llama2',
      endpoint: 'https://api.ollama.ai/api/chat', // Free hosted endpoint
      needsKey: false,
      description: 'FREE - Run locally or cloud',
      color: 'from-green-600 to-teal-600',
      category: 'Free',
      cost: 0, // FREE!
      speed: 'fast',
      reliability: 0.93,
      localEndpoint: 'http://localhost:11434/api/chat'
    },
    groq: {
      id: 'groq',
      name: 'Groq',
      icon: '⚡',
      models: ['mixtral-8x7b-32768'],
      defaultModel: 'mixtral-8x7b-32768',
      endpoint: 'https://api.groq.com/openai/v1/chat/completions',
      needsKey: true,
      description: 'Ultra-fast - 500+ tok/sec',
      color: 'from-orange-600 to-red-600',
      category: 'Performance',
      cost: 0.27, // per 1M tokens
      speed: 'ultra-fast',
      reliability: 0.95
    },
    openai: {
      id: 'openai',
      name: 'OpenAI',
      icon: '⚡',
      models: ['gpt-4-turbo-preview', 'gpt-3.5-turbo'],
      defaultModel: 'gpt-4-turbo-preview',
      endpoint: 'https://api.openai.com/v1/chat/completions',
      needsKey: true,
      description: 'GPT-4 - High quality',
      color: 'from-green-600 to-emerald-600',
      category: 'Premium',
      cost: 30, // per 1M tokens (GPT-4)
      speed: 'medium',
      reliability: 0.99
    },
    gemini: {
      id: 'gemini',
      name: 'Gemini',
      icon: '🔮',
      models: ['gemini-pro'],
      defaultModel: 'gemini-pro',
      endpoint: 'https://generativelanguage.googleapis.com/v1beta/models/',
      needsKey: true,
      description: 'Google AI - Multimodal',
      color: 'from-blue-600 to-cyan-600',
      category: 'Premium',
      cost: 7,
      speed: 'medium',
      reliability: 0.96
    },
    together: {
      id: 'together',
      name: 'Together AI',
      icon: '🌐',
      models: ['mistralai/Mixtral-8x7B-Instruct-v0.1'],
      defaultModel: 'mistralai/Mixtral-8x7B-Instruct-v0.1',
      endpoint: 'https://api.together.xyz/v1/chat/completions',
      needsKey: true,
      description: 'Open source - Affordable',
      color: 'from-indigo-600 to-purple-600',
      category: 'Open Source',
      cost: 0.6,
      speed: 'fast',
      reliability: 0.94
    }
  };

  // Domain agents
  const domainAgents = [
    { id: 'marketing', name: 'Marketing', icon: TrendingUp, color: 'bg-purple-500', expertise: ['social media', 'campaigns', 'seo'], prompt: "You are a marketing expert for PES." },
    { id: 'ecommerce', name: 'E-Commerce', icon: ShoppingCart, color: 'bg-green-500', expertise: ['products', 'sales'], prompt: "You are an e-commerce specialist for PES." },
    { id: 'software', name: 'Software Dev', icon: Code, color: 'bg-blue-500', expertise: ['coding', 'apis'], prompt: "You are a senior developer for PES." },
    { id: 'content', name: 'Content', icon: FileText, color: 'bg-orange-500', expertise: ['writing', 'blogs'], prompt: "You are a content writer for PES." },
    { id: 'data', name: 'Data Analytics', icon: BarChart3, color: 'bg-indigo-500', expertise: ['analytics', 'reports'], prompt: "You are a data analyst for PES." },
    { id: 'sales', name: 'Sales', icon: DollarSign, color: 'bg-emerald-500', expertise: ['leads', 'conversion'], prompt: "You are a sales expert for PES." },
    { id: 'customer', name: 'Customer Service', icon: MessageSquare, color: 'bg-pink-500', expertise: ['support', 'tickets'], prompt: "You are a customer service specialist for PES." },
    { id: 'finance', name: 'Finance', icon: Briefcase, color: 'bg-yellow-500', expertise: ['budgeting', 'invoicing'], prompt: "You are a financial manager for PES." },
    { id: 'hr', name: 'HR', icon: Users, color: 'bg-cyan-500', expertise: ['recruitment', 'training'], prompt: "You are an HR specialist for PES." },
    { id: 'design', name: 'Design', icon: Palette, color: 'bg-rose-500', expertise: ['graphics', 'branding'], prompt: "You are a designer for PES." },
    { id: 'project', name: 'Project Mgmt', icon: Target, color: 'bg-violet-500', expertise: ['planning', 'coordination'], prompt: "You are a project manager for PES." },
    { id: 'social', name: 'Social Media', icon: Share2, color: 'bg-sky-500', expertise: ['posting', 'engagement'], prompt: "You are a social media manager for PES." }
  ];

  const masterPrompt = `You are the MASTER ORCHESTRATOR AI for PES. Route tasks intelligently and provide strategic guidance.`;

  // Load from localStorage
  useEffect(() => {
    try {
      const savedKeys = localStorage.getItem('orchestrator_api_keys');
      const savedModel = localStorage.getItem('orchestrator_selected_model');
      const savedCache = localStorage.getItem('orchestrator_cache');
      const savedHistory = localStorage.getItem('orchestrator_routing_history');
      const savedPerformance = localStorage.getItem('orchestrator_performance');
      const savedCost = localStorage.getItem('orchestrator_total_cost');
      const savedQueryHistory = localStorage.getItem('orchestrator_query_history');
      
      if (savedKeys) setApiKeys(JSON.parse(savedKeys));
      if (savedModel) setSelectedModel(savedModel);
      if (savedCache) setQueryCache(JSON.parse(savedCache));
      if (savedHistory) setRoutingHistory(JSON.parse(savedHistory));
      if (savedPerformance) setModelPerformance(JSON.parse(savedPerformance));
      if (savedCost) setTotalCost(parseFloat(savedCost));
      if (savedQueryHistory) setQueryHistory(JSON.parse(savedQueryHistory));
    } catch (e) {
      console.error('Error loading saved data:', e);
    }
  }, []);

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('orchestrator_api_keys', JSON.stringify(apiKeys));
      localStorage.setItem('orchestrator_selected_model', selectedModel);
      localStorage.setItem('orchestrator_cache', JSON.stringify(queryCache));
      localStorage.setItem('orchestrator_routing_history', JSON.stringify(routingHistory));
      localStorage.setItem('orchestrator_performance', JSON.stringify(modelPerformance));
      localStorage.setItem('orchestrator_total_cost', totalCost.toString());
      localStorage.setItem('orchestrator_query_history', JSON.stringify(queryHistory));
    } catch (e) {
      console.error('Error saving data:', e);
    }
  }, [apiKeys, selectedModel, queryCache, routingHistory, modelPerformance, totalCost, queryHistory]);

  // Online/offline detection
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Cache key generator
  const getCacheKey = (message, model, agents) => {
    return `${message.toLowerCase().trim()}_${model}_${agents.join(',')}`;
  };

  // Check cache
  const checkCache = (message, model, agents) => {
    const key = getCacheKey(message, model, agents);
    const cached = queryCache[key];
    
    if (cached && Date.now() - cached.timestamp < 3600000) { // 1 hour cache
      return cached.response;
    }
    return null;
  };

  // Update cache
  const updateCache = (message, model, agents, response) => {
    const key = getCacheKey(message, model, agents);
    setQueryCache(prev => ({
      ...prev,
      [key]: {
        response,
        timestamp: Date.now()
      }
    }));
  };

  // Smart model selection based on query and budget
  const selectBestModel = useCallback((queryType, priority) => {
    const availableModels = Object.values(aiModels).filter(m => 
      !m.needsKey || apiKeys[m.id]
    );

    if (priority === 'urgent' || queryType === 'simple') {
      // Use fastest model
      return availableModels.sort((a, b) => {
        const speedOrder = { 'ultra-fast': 0, 'fast': 1, 'medium': 2 };
        return speedOrder[a.speed] - speedOrder[b.speed];
      })[0]?.id || 'claude';
    }

    if (priority === 'low' || totalCost > 10) {
      // Use free/cheapest model
      return availableModels.sort((a, b) => a.cost - b.cost)[0]?.id || 'claude';
    }

    // Default to current selection
    return selectedModel;
  }, [apiKeys, selectedModel, totalCost]);

  // Universal AI caller with retry and fallback
  const callAIModel = async (systemPrompt, userMessage, modelId, retryCount = 0) => {
    const config = aiModels[modelId];
    const startTime = Date.now();

    try {
      let response, data, result;

      if (config.id === 'claude') {
        response = await fetch(config.endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: config.defaultModel,
            max_tokens: 2000, // Reduced for efficiency
            system: systemPrompt,
            messages: [{ role: 'user', content: userMessage }]
          })
        });
        data = await response.json();
        result = data.content[0].text;
      } else if (['openai', 'groq', 'together'].includes(config.id)) {
        const apiKey = apiKeys[config.id];
        if (!apiKey) throw new Error(`${config.name} API key not configured`);
        
        response = await fetch(config.endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model: config.defaultModel,
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: userMessage }
            ],
            max_tokens: 2000
          })
        });
        data = await response.json();
        result = data.choices[0].message.content;
      } else if (config.id === 'gemini') {
        const apiKey = apiKeys[config.id];
        if (!apiKey) throw new Error('Gemini API key not configured');
        
        response = await fetch(`${config.endpoint}${config.defaultModel}:generateContent?key=${apiKey}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{
              parts: [{ text: `${systemPrompt}\n\nUser: ${userMessage}` }]
            }]
          })
        });
        data = await response.json();
        result = data.candidates[0].content.parts[0].text;
      } else if (config.id === 'ollama') {
        // Try hosted endpoint first, fallback to local if available
        const useLocal = apiKeys['ollama_use_local'] === 'true';
        const endpoint = useLocal ? config.localEndpoint : config.endpoint;
        const selectedModel = apiKeys['ollama_model'] || config.defaultModel;
        
        try {
          response = await fetch(endpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              model: selectedModel,
              messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userMessage }
              ],
              stream: false
            })
          });
          data = await response.json();
          result = data.message?.content || data.response || 'No response from Ollama';
        } catch (ollamaError) {
          // If hosted fails and not using local, try local as fallback
          if (!useLocal) {
            try {
              response = await fetch(config.localEndpoint, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  model: selectedModel,
                  messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userMessage }
                  ],
                  stream: false
                })
              });
              data = await response.json();
              result = data.message?.content || data.response || 'No response from Ollama';
            } catch (localError) {
              throw new Error('Ollama not available. Install locally or use hosted endpoint.');
            }
          } else {
            throw ollamaError;
          }
        }
      }

      // Track performance
      const duration = Date.now() - startTime;
      setModelPerformance(prev => ({
        ...prev,
        [modelId]: {
          calls: (prev[modelId]?.calls || 0) + 1,
          totalTime: (prev[modelId]?.totalTime || 0) + duration,
          avgTime: ((prev[modelId]?.totalTime || 0) + duration) / ((prev[modelId]?.calls || 0) + 1),
          lastUsed: Date.now()
        }
      }));

      // Track cost
      const tokens = Math.ceil(result.length / 4); // Rough estimate
      const cost = (tokens / 1000000) * config.cost;
      setTotalCost(prev => prev + cost);

      return result;
    } catch (error) {
      console.error(`Error with ${config.name}:`, error);

      // Auto-fallback to Claude if available
      if (retryCount < 2 && modelId !== 'claude') {
        console.log(`Falling back to Claude...`);
        return await callAIModel(systemPrompt, userMessage, 'claude', retryCount + 1);
      }

      throw error;
    }
  };

  // Optimized routing with learning
  const routeToAgents = async (userMessage) => {
    // Check routing history for similar queries
    const similar = routingHistory.find(h => 
      h.query.toLowerCase().includes(userMessage.toLowerCase().substring(0, 20))
    );
    
    if (similar && similar.success) {
      return similar.routing;
    }

    try {
      const routingPrompt = `Analyze and route to agents: ${domainAgents.map(a => a.id).join(', ')}. Return JSON: {"agents":["agent1"],"complexity":"simple|medium|complex","priority":"low|medium|high"}`;
      
      const responseText = await callAIModel(
        routingPrompt,
        `Route: "${userMessage}"`,
        'claude' // Always use free Claude for routing
      );
      
      const cleaned = responseText.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      const routing = JSON.parse(cleaned);
      
      // Save to history
      setRoutingHistory(prev => [...prev.slice(-50), { // Keep last 50
        query: userMessage,
        routing,
        timestamp: Date.now(),
        success: true
      }]);
      
      return routing;
    } catch (error) {
      return {
        agents: ['marketing'],
        complexity: 'medium',
        priority: 'medium'
      };
    }
  };

  // Main message handler with all optimizations
  const sendMessage = useCallback(async (messageText = input) => {
    if (!messageText.trim() || loading || !isOnline) return;

    const userMessage = { role: 'user', content: messageText };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setLoading(true);
    setSystemStatus('processing');

    try {
      // Route to agents
      const routing = await routeToAgents(messageText);
      setActiveAgents(routing.agents);

      // Select best model for this task
      const bestModel = selectBestModel(routing.complexity, routing.priority);
      
      // Check cache first
      const cached = checkCache(messageText, bestModel, routing.agents);
      if (cached) {
        const assistantMessage = {
          role: 'assistant',
          content: `💾 [Cached] ${cached}`
        };
        setMessages([...newMessages, assistantMessage]);
        setLoading(false);
        setSystemStatus('operational');
        setActiveAgents([]);
        return;
      }

      // Add to task queue
      const task = {
        id: Date.now(),
        message: messageText,
        agents: routing.agents,
        priority: routing.priority,
        model: bestModel,
        status: 'processing'
      };
      setTaskQueue(prev => [...prev, task]);

      // Execute
      let finalResponse;
      
      if (routing.agents.length === 1) {
        const agent = domainAgents.find(a => a.id === routing.agents[0]);
        const response = await callAIModel(agent.prompt, messageText, bestModel);
        finalResponse = `🤖 **${agent.name}** (${aiModels[bestModel].icon} ${aiModels[bestModel].name}):\n\n${response}`;
      } else {
        // Simplified multi-agent for efficiency
        const mainAgent = domainAgents.find(a => a.id === routing.agents[0]);
        const response = await callAIModel(mainAgent.prompt, messageText, bestModel);
        finalResponse = `🧠 **Orchestrator** (${aiModels[bestModel].icon}):\n\n${response}`;
      }

      // Update cache
      updateCache(messageText, bestModel, routing.agents, finalResponse);

      // Save to query history
      setQueryHistory(prev => [...prev.slice(-20), { // Keep last 20
        query: messageText,
        response: finalResponse,
        model: bestModel,
        agents: routing.agents,
        timestamp: Date.now()
      }]);

      const assistantMessage = {
        role: 'assistant',
        content: finalResponse
      };

      setMessages([...newMessages, assistantMessage]);
      
      setTaskQueue(prev => prev.map(t => 
        t.id === task.id ? { ...t, status: 'completed' } : t
      ));

      routing.agents.forEach(agentId => {
        setAgentInsights(prev => ({
          ...prev,
          [agentId]: (prev[agentId] || 0) + 1
        }));
      });

    } catch (error) {
      setMessages([...newMessages, {
        role: 'assistant',
        content: `⚠️ Error: ${error.message}`
      }]);
      setSystemStatus('error');
    } finally {
      setLoading(false);
      setSystemStatus('operational');
      setActiveAgents([]);
    }
  }, [input, loading, messages, isOnline]);

  // Debounced input for efficiency
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const clearChat = () => {
    setMessages([]);
    setTaskQueue([]);
  };

  const exportData = () => {
    const data = {
      messages,
      queryHistory,
      routingHistory,
      modelPerformance,
      totalCost,
      timestamp: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `orchestrator-data-${Date.now()}.json`;
    a.click();
  };

  const quickCommands = [
    "Quick marketing tips for social media",
    "Analyze sales trends",
    "Generate content ideas",
    "Budget planning advice"
  ];

  // Memoized stats for performance
  const stats = useMemo(() => ({
    totalQueries: queryHistory.length,
    cachedQueries: Object.keys(queryCache).length,
    avgResponseTime: Object.values(modelPerformance).reduce((acc, m) => acc + (m.avgTime || 0), 0) / Object.keys(modelPerformance).length || 0,
    mostUsedAgent: Object.entries(agentInsights).sort((a, b) => b[1] - a[1])[0]?.[0] || 'none'
  }), [queryHistory, queryCache, modelPerformance, agentInsights]);

  // Settings Modal
  const SettingsModal = () => {
    const [tempKeys, setTempKeys] = useState({ ...apiKeys });

    return (
      <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-gradient-to-br from-slate-900 to-purple-900 rounded-2xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-purple-500/30">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-white">Ultra-Optimized Configuration</h2>
              <p className="text-purple-300 text-sm">6 AI Models (2 FREE!) • Smart Routing • Auto-Fallback</p>
            </div>
            <button onClick={() => setShowSettings(false)} className="text-gray-400 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Stats Dashboard */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            <div className="bg-white/5 rounded-lg p-3 border border-white/10">
              <div className="text-purple-300 text-xs">Total Queries</div>
              <div className="text-white text-2xl font-bold">{stats.totalQueries}</div>
            </div>
            <div className="bg-white/5 rounded-lg p-3 border border-white/10">
              <div className="text-green-300 text-xs">Cached</div>
              <div className="text-white text-2xl font-bold">{stats.cachedQueries}</div>
            </div>
            <div className="bg-white/5 rounded-lg p-3 border border-white/10">
              <div className="text-blue-300 text-xs">Avg Response</div>
              <div className="text-white text-2xl font-bold">{Math.round(stats.avgResponseTime)}ms</div>
            </div>
            <div className="bg-white/5 rounded-lg p-3 border border-white/10">
              <div className="text-yellow-300 text-xs">Total Cost</div>
              <div className="text-white text-2xl font-bold">${totalCost.toFixed(4)}</div>
            </div>
          </div>

          {/* Model Selection */}
          <div className="mb-6">
            <h3 className="text-white font-semibold mb-3">AI Models (Click to Select)</h3>
            <div className="grid md:grid-cols-2 gap-3">
              {Object.values(aiModels).map((model) => (
                <button
                  key={model.id}
                  onClick={() => {
                    localStorage.setItem('orchestrator_selected_model', model.id);
                    setSelectedModel(model.id);
                  }}
                  className={`p-4 rounded-xl border-2 transition-all text-left ${
                    selectedModel === model.id
                      ? 'border-purple-500 bg-gradient-to-r ' + model.color + ' bg-opacity-20'
                      : 'border-white/10 bg-white/5 hover:border-white/30'
                  }`}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-3xl">{model.icon}</span>
                    <div className="flex-1">
                      <div className="text-white font-bold">{model.name}</div>
                      <div className="text-xs text-gray-400">{model.description}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className={`${model.cost === 0 ? 'text-green-400' : 'text-yellow-400'}`}>
                      {model.cost === 0 ? 'FREE' : `$${model.cost}/1M`}
                    </span>
                    <span className="text-blue-400">{model.speed}</span>
                    {selectedModel === model.id && <span className="text-purple-300">✓ Active</span>}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* API Keys */}
          <div className="mb-6">
            <h3 className="text-white font-semibold mb-3">API Keys (Optional)</h3>
            <div className="space-y-2">
              {Object.values(aiModels).filter(m => m.needsKey).map((model) => (
                <div key={model.id} className="flex gap-2 items-center bg-white/5 p-3 rounded-lg">
                  <span className="text-xl">{model.icon}</span>
                  <input
                    type={showApiKey[model.id] ? "text" : "password"}
                    value={tempKeys[model.id] || ''}
                    onChange={(e) => setTempKeys({ ...tempKeys, [model.id]: e.target.value })}
                    placeholder={`${model.name} API key`}
                    className="flex-1 bg-white/10 border border-white/20 rounded px-3 py-2 text-white text-sm"
                  />
                  <button
                    onClick={() => setShowApiKey({ ...showApiKey, [model.id]: !showApiKey[model.id] })}
                    className="p-2 bg-white/10 rounded hover:bg-white/20"
                  >
                    {showApiKey[model.id] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Ollama Configuration */}
          <div className="mb-6 p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">🦙</span>
              <h3 className="text-white font-semibold">Ollama FREE LLM</h3>
              <span className="text-xs px-2 py-1 bg-green-500 text-white rounded">100% FREE</span>
            </div>
            
            <div className="space-y-3">
              {/* Model Selection */}
              <div>
                <label className="text-purple-300 text-sm mb-1 block">Select Model:</label>
                <select
                  value={tempKeys['ollama_model'] || 'llama2'}
                  onChange={(e) => setTempKeys({ ...tempKeys, ollama_model: e.target.value })}
                  className="w-full bg-white/10 border border-white/20 rounded px-3 py-2 text-white text-sm"
                >
                  <option value="llama2">Llama 2 (7B) - Balanced</option>
                  <option value="llama2:13b">Llama 2 (13B) - Better quality</option>
                  <option value="mistral">Mistral (7B) - Fast & smart</option>
                  <option value="codellama">CodeLlama - Best for code</option>
                  <option value="phi">Phi (2.7B) - Ultra-fast, small</option>
                  <option value="neural-chat">Neural Chat - Conversational</option>
                  <option value="orca-mini">Orca Mini - Lightweight</option>
                </select>
              </div>

              {/* Local vs Hosted */}
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={tempKeys['ollama_use_local'] === 'true'}
                    onChange={(e) => setTempKeys({ ...tempKeys, ollama_use_local: e.target.checked ? 'true' : 'false' })}
                    className="w-4 h-4"
                  />
                  <span className="text-purple-300 text-sm">Use Local Ollama (localhost:11434)</span>
                </label>
              </div>

              {/* Info */}
              <div className="text-xs text-purple-300 space-y-1">
                <p>🌐 <strong>Hosted (Default):</strong> Free cloud endpoint - No setup needed!</p>
                <p>💻 <strong>Local:</strong> Install Ollama locally for full control</p>
                <p>📥 <strong>Install:</strong> <code className="bg-white/10 px-1 rounded">curl https://ollama.ai/install.sh | sh</code></p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <button
              onClick={() => {
                localStorage.setItem('orchestrator_api_keys', JSON.stringify(tempKeys));
                setApiKeys(tempKeys);
                setShowSettings(false);
              }}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <Save className="w-5 h-5" />
              Save Configuration
            </button>
            <button
              onClick={exportData}
              className="px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-all"
            >
              <Download className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 p-4">
      <div className="max-w-7xl mx-auto">
        {showSettings && <SettingsModal />}

        {/* Compact Header */}
        <div className="bg-gradient-to-r from-purple-900/40 to-pink-900/40 backdrop-blur-lg rounded-2xl p-4 mb-4 border border-purple-500/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-xl">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Ultra-Optimized Orchestrator</h1>
                <p className="text-purple-200 text-sm">Smart • Efficient • FREE</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowSettings(true)}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-all"
              >
                <Settings className="w-5 h-5 text-white" />
              </button>
              <div className={`flex items-center gap-1 px-3 py-1 rounded-lg text-sm ${
                isOnline ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'
              }`}>
                {isOnline ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
              </div>
            </div>
          </div>
          
          {/* Compact Stats */}
          <div className="flex gap-4 mt-3 text-xs text-purple-300">
            <span>📊 {stats.totalQueries} queries</span>
            <span>💾 {stats.cachedQueries} cached</span>
            <span>💰 ${totalCost.toFixed(4)}</span>
            <span>⚡ {Math.round(stats.avgResponseTime)}ms avg</span>
          </div>
        </div>

        {/* Compact Agent Grid */}
        <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-12 gap-2 mb-4">
          {domainAgents.map((agent) => {
            const Icon = agent.icon;
            const count = agentInsights[agent.id] || 0;
            return (
              <div key={agent.id} className="bg-white/5 backdrop-blur rounded-lg p-2 border border-white/10 hover:scale-105 transition-all">
                <div className={`${agent.color} w-8 h-8 rounded flex items-center justify-center mx-auto mb-1`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <div className="text-center text-xs text-white">{count}</div>
              </div>
            );
          })}
        </div>

        {/* Quick Commands */}
        {messages.length === 0 && (
          <div className="grid grid-cols-2 gap-2 mb-4">
            {quickCommands.map((cmd, idx) => (
              <button
                key={idx}
                onClick={() => sendMessage(cmd)}
                className="text-left p-3 bg-white/5 hover:bg-white/10 rounded-lg text-purple-200 text-sm border border-white/10"
              >
                {cmd}
              </button>
            ))}
          </div>
        )}

        {/* Chat */}
        <div className="bg-white/5 backdrop-blur rounded-2xl border border-white/10 overflow-hidden">
          <div className="h-[500px] overflow-y-auto p-4 space-y-3">
            {messages.length === 0 ? (
              <div className="text-center py-20">
                <div className="bg-gradient-to-br from-purple-500 to-pink-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Ultra-Optimized & Ready</h3>
                <p className="text-purple-200">Smart caching • Auto-fallback • Cost tracking • FREE with Claude!</p>
              </div>
            ) : (
              messages.map((msg, idx) => (
                <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-3 rounded-xl text-sm ${
                    msg.role === 'user'
                      ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                      : 'bg-white/10 text-white border border-white/20'
                  }`}>
                    {msg.content}
                  </div>
                </div>
              ))
            )}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-white/10 border border-white/20 p-3 rounded-xl flex items-center gap-2">
                  <Loader className="w-4 h-4 text-purple-400 animate-spin" />
                  <span className="text-purple-200 text-sm">Processing...</span>
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="p-3 bg-white/5 border-t border-white/10">
            <div className="flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask anything..."
                className="flex-1 bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-500"
                disabled={loading || !isOnline}
              />
              <button
                onClick={() => sendMessage()}
                disabled={loading || !input.trim() || !isOnline}
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-2 rounded-lg hover:shadow-lg transition-all disabled:opacity-50"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-3 text-center text-purple-300 text-xs">
          <p>Ultra-Optimized • Smart Caching • Auto-Fallback • Cost Tracking • 6 AI Models (2 FREE!)</p>
        </div>
      </div>
    </div>
  );
}
